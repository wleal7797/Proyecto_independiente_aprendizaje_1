package co.edu.unbosque.model;

public class Data_Base_Final {
	private String codigo, nombreEmpleado, nombreDependencia, nombreCargo,
	fechaInicioIncapacidad, fechaTerminacionIncapacidad, numDiasTrabajosMes, periodoVacaciones,
	totalBonificacion, totalTransporte, salarioTotal, FechaIngreso, Eps, Sueldo, pension, incapacidad, fechaInicioVacaciones, fechaTerminacionVacaciones;
	
	

	public String getFechaInicioVacaciones() {
		return fechaInicioVacaciones;
	}

	public void setFechaInicioVacaciones(String fechaInicioVacaciones) {
		this.fechaInicioVacaciones = fechaInicioVacaciones;
	}

	public String getFechaTerminacionVacaciones() {
		return fechaTerminacionVacaciones;
	}

	public void setFechaTerminacionVacaciones(String fechaTerminacionVacaciones) {
		this.fechaTerminacionVacaciones = fechaTerminacionVacaciones;
	}

	public String getIncapacidad() {
		return incapacidad;
	}

	public void setIncapacidad(String incapacidad) {
		this.incapacidad = incapacidad;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	public String getNombreDependencia() {
		return nombreDependencia;
	}

	public void setNombreDependencia(String nombreDependencia) {
		this.nombreDependencia = nombreDependencia;
	}

	public String getNombreCargo() {
		return nombreCargo;
	}

	public void setNombreCargo(String nombreCargo) {
		this.nombreCargo = nombreCargo;
	}

	public String getFechaInicioIncapacidad() {
		return fechaInicioIncapacidad;
	}

	public void setFechaInicioIncapacidad(String fechaInicioIncapacidad) {
		this.fechaInicioIncapacidad = fechaInicioIncapacidad;
	}

	public String getFechaTerminacionIncapacidad() {
		return fechaTerminacionIncapacidad;
	}

	public void setFechaTerminacionIncapacidad(String fechaTerminacionIncapacidad) {
		this.fechaTerminacionIncapacidad = fechaTerminacionIncapacidad;
	}

	public String getNumDiasTrabajosMes() {
		return numDiasTrabajosMes;
	}

	public void setNumDiasTrabajosMes(String numDiasTrabajosMes) {
		this.numDiasTrabajosMes = numDiasTrabajosMes;
	}

	public String getPeriodoVacaciones() {
		return periodoVacaciones;
	}

	public void setPeriodoVacaciones(String periodoVacaciones) {
		this.periodoVacaciones = periodoVacaciones;
	}

	public String getTotalBonificacion() {
		return totalBonificacion;
	}

	public void setTotalBonificacion(String totalBonificacion) {
		this.totalBonificacion = totalBonificacion;
	}

	public String getTotalTransporte() {
		return totalTransporte;
	}

	public void setTotalTransporte(String totalTransporte) {
		this.totalTransporte = totalTransporte;
	}

	public String getSalarioTotal() {
		return salarioTotal;
	}

	public void setSalarioTotal(String salarioTotal) {
		this.salarioTotal = salarioTotal;
	}

	public String getFechaIngreso() {
		return FechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		FechaIngreso = fechaIngreso;
	}

	public String getEps() {
		return Eps;
	}

	public void setEps(String eps) {
		Eps = eps;
	}

	public String getSueldo() {
		return Sueldo;
	}

	public void setSueldo(String sueldo) {
		Sueldo = sueldo;
	}

	public String getPension() {
		return pension;
	}

	public void setPension(String pension) {
		this.pension = pension;
	}
	
	
}
